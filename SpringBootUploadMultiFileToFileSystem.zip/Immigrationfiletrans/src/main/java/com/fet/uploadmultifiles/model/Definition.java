package com.fet.uploadmultifiles.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.ArrayList;

public class Definition {

    @JacksonXmlProperty(localName = "description")
    private String description;

    @JacksonXmlProperty(localName = "dataset")
    private DataSet dateSet;

    public Definition(){

    }

    public Definition(String description, DataSet dateSet) {
        this.description = description;
        this.dateSet = dateSet;
    }

    public DataSet getDateSet() {
        return dateSet;
    }

    public void setDateSet(DataSet dateSet) {
        this.dateSet = dateSet;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
