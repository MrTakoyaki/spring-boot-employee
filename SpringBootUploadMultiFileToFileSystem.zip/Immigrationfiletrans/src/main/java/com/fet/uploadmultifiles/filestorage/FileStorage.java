package com.fet.uploadmultifiles.filestorage;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.stream.Stream;

import com.fet.uploadmultifiles.model.Document;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;
 
public interface FileStorage {
	public void store(MultipartFile file);
	public Resource loadFile(String filename);
	public Resource loadFileFromTarget(String filename);
	public void deleteAll();
	public void init();
	public void downloadInit();
	public Stream<Path> loadFiles();
	public Stream<Path> loadFilesFromTarget();
	public ArrayList<Document> fileToObject();
	public void objectToXml(Document document);
}
