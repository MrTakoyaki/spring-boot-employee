package com.fet.uploadmultifiles.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "Document")
public class Document {

    @JacksonXmlProperty(localName = "h1")
    private String hOne;

    @JacksonXmlProperty(localName = "descriptions")
    private String descriptions;

    @JacksonXmlProperty(localName = "definition")
    private Definition definition;

    public Document(){

    }

    public Document(String hOne, String descriptions, Definition definition) {
        this.hOne = hOne;
        this.descriptions = descriptions;
        this.definition = definition;
    }

    public Definition getDefinition() {
        return definition;
    }

    public void setDefinition(Definition definition) {
        this.definition = definition;
    }

    public String gethOne() {
        return hOne;
    }

    public void sethOne(String hOne) {
        this.hOne = hOne;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }
}
