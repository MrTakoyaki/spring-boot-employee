package com.fet.uploadmultifiles.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fet.uploadmultifiles.filestorage.FileStorage;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UploadFileController {

	private final String UPLOAD_DIR = "./uploads/";

	@Autowired
	FileStorage fileStorage;
	
    @GetMapping("/")
    public String index() {
        return "uploadform";
    }

//	@GetMapping("/index")
//	public String index2() {
//		return "index";
//	}
    
//    @PostMapping("/")
//    public String uploadMultipartFile(@RequestParam("files") MultipartFile[] files, Model model) {
//    	List<String> fileNames = null;
//
//		try {
//	        fileNames = Arrays.asList(files)
//	                .stream()
//	                .map(file -> {
//	                	fileStorage.store(file);
//	                	return file.getOriginalFilename();
//	                })
//	                .collect(Collectors.toList());
//
//			model.addAttribute("message", "Files uploaded successfully!");
//			model.addAttribute("files", fileNames);
//		} catch (Exception e) {
//			model.addAttribute("message", "Fail!");
//			model.addAttribute("files", fileNames);
//		}
//
//        return "uploadform";
//    }

	@PostMapping("/upload")
	public String upload(@RequestParam("file") MultipartFile file, RedirectAttributes attributes) {
		// check if file is empty
		if (file.isEmpty()) {
			attributes.addFlashAttribute("message", "Please select a file to upload.");
			return "redirect:/";
		}

		// normalize the file path
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		// save the file on the local file system
		try {
			Path path = Paths.get(UPLOAD_DIR + fileName);

			Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			e.printStackTrace();
		}

		// return success response
//		log.info("uploaded file " + file.getOriginalFilename());
		return "redirect:/";
	}
    
}