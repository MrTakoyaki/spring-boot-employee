package com.fet.uploadmultifiles.filestorage;

import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fet.uploadmultifiles.controller.DownloadFileController;
import com.fet.uploadmultifiles.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

@Service
public class FileStorageImpl implements FileStorage{
	
	Logger log = LoggerFactory.getLogger(this.getClass().getName());
	private final Path rootLocation = Paths.get("uploads");
    private final Path downloadLocation = Paths.get("download");
 
	@Override
	public void store(MultipartFile file){
		try {
            Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
        	throw new RuntimeException("FAIL! -> message = " + e.getMessage());
        }
	}
	
	@Override
    public Resource loadFile(String filename) {
        try {
            Path file = rootLocation.resolve(filename);
            Resource resource = new UrlResource(file.toUri());
            if(resource.exists() || resource.isReadable()) {
                return resource;
            }else{
            	throw new RuntimeException("FAIL!");
            }
        } catch (MalformedURLException e) {
        	throw new RuntimeException("Error! -> message = " + e.getMessage());
        }
    }

    @Override
    public Resource loadFileFromTarget(String filename) {
        try {
            Path file = downloadLocation.resolve(filename);
            Resource resource = new UrlResource(file.toUri());
            if(resource.exists() || resource.isReadable()) {
                return resource;
            }else{
                throw new RuntimeException("FAIL!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error! -> message = " + e.getMessage());
        }
    }

    @Override
    public void deleteAll() {
        FileSystemUtils.deleteRecursively(rootLocation.toFile());
        FileSystemUtils.deleteRecursively(downloadLocation.toFile());
    }

	@Override
    public void init() {
        try {
            Files.createDirectory(rootLocation);
            Files.createDirectory(downloadLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage!");
        }
    }

    @Override
    public void downloadInit() {
        FileSystemUtils.deleteRecursively(downloadLocation.toFile());
        try {
            Files.createDirectory(downloadLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage!");
        }
    }

    @Override
	public Stream<Path> loadFiles() {
        try {
            return Files.walk(this.rootLocation, 1)
                .filter(path -> !path.equals(this.rootLocation))
                .map(this.rootLocation::relativize);
        }
        catch (IOException e) {
        	throw new RuntimeException("\"Failed to read stored file");
        }
//        try {
//            return Files.walk(this.downloadLocation, 1)
//                    .filter(path -> !path.equals(this.downloadLocation))
//                    .map(this.downloadLocation::relativize);
//        }
//        catch (IOException e) {
//            throw new RuntimeException("\"Failed to read stored file");
//        }
	}

    @Override
    public Stream<Path> loadFilesFromTarget() {
                try {
            return Files.walk(this.downloadLocation, 1)
                .filter(path -> !path.equals(this.downloadLocation))
                .map(this.downloadLocation::relativize);
        }
        catch (IOException e) {
        	throw new RuntimeException("\"Failed to read stored file");
        }
    }

    @Override
    public ArrayList<Document> fileToObject() {
        List<FileInfo> fileInfos = this.loadFiles().map(
                path ->	{
                    String filename = path.getFileName().toString();
                    String url = MvcUriComponentsBuilder.fromMethodName(DownloadFileController.class,
                            "downloadFile", path.getFileName().toString()).build().toString();
                    return new FileInfo(filename, url);
                }
        )
                .collect(Collectors.toList());

        ArrayList<Document> documentArrayList = new ArrayList<>();
        File sourceFile = null;
        try {
            InputStreamReader isr = null;
            BufferedReader reader = null;

//            BufferedWriter bw = null;
            String line = null;
            for(int i = 0; i < fileInfos.size(); i++) {
                if (fileInfos.get(i).getFilename().endsWith(".csv") || fileInfos.get(i).getFilename().endsWith(".CSV")) {
                    isr = new InputStreamReader(new FileInputStream(this.rootLocation + "/" + fileInfos.get(i).getFilename()));//檔案讀取路徑
                    reader = new BufferedReader(isr);
//                bw = new BufferedWriter(new FileWriter("D://file_output.csv"));//檔案輸出路徑
                    ArrayList<Row> rowArrayList = new ArrayList<>();
                    while ((line = reader.readLine()) != null) {
                    String[] item = line.split(",");
//                        System.out.println("LINE :" + line);
                        rowArrayList.add(this.createRow(item));
                    }

                    this.objectToXml(new Document("Document", "XML Format",
                            new Definition(fileInfos.get(i).getFilename().replace(".csv",""),
                                    new DataSet(rowArrayList))));
                    isr.close();
                    sourceFile = new File(this.rootLocation + "/" + fileInfos.get(i).getFilename());
                    sourceFile.delete();
                } else {
                    sourceFile = new File(this.rootLocation + "/" + fileInfos.get(i).getFilename());
                    sourceFile.delete();
                }
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        return documentArrayList;
    }

    @Override
    public void objectToXml(Document document) {
        ObjectMapper xmlMapper = new XmlMapper();
        File file = new File(this.downloadLocation+ "/" + document.getDefinition().getDescription() + ".xml");
//        File sourceFile = new File(this.rootLocation+ "/" + document.getDefinition().getDescription() + ".csv");
        try {
            System.out.println(xmlMapper.writeValueAsString(document));
            xmlMapper.writeValue(file,document);

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Row createRow(String[] item){

	    switch (item.length){
            case 1: return new Row(item[0]);
            case 2: return new Row(item[0],item[1]);
            case 3: return new Row(item[0],item[1],item[2]);
            case 4: return new Row(item[0],item[1],item[2],item[3]);
            case 5: return new Row(item[0],item[1],item[2],item[3],item[4]);
            case 6: return new Row(item[0],item[1],item[2],item[3],item[4],item[5]);
            case 7: return new Row(item[0],item[1],item[2],item[3],item[4],item[5],item[6]);
            case 8: return new Row(item[0],item[1],item[2],item[3],item[4],item[5],item[6],item[7]);
            case 9: return new Row(item[0],item[1],item[2],item[3],item[4],item[5],item[6],item[7],item[8]);
            case 10: return new Row(item[0],item[1],item[2],item[3],item[4],
                                   item[5],item[6],item[7],item[8],item[9]);
            case 11: return new Row(item[0],item[1],item[2],item[3],item[4],
                                   item[5],item[6],item[7],item[8],item[9],item[10]);
            case 12: return new Row(item[0],item[1],item[2],item[3],item[4],
                                        item[5],item[6],item[7],item[8],item[9],item[10],item[11]);
            default: return new Row();
        }

    }

    public static void main(String[] args) {
//        FileStorageImpl fileStorage = new FileStorageImpl();
//        fileStorage.fileToObject();
    }


}